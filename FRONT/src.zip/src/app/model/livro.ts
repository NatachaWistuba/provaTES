class Livro {
    

    constructor(
       public id?: String,
       public nome?: String,
       public preco?: number,
       public isbn?: number,
    ){}
}


export default Livro;