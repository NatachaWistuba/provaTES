import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
<app-cadastrar></app-cadastrar>  
  `,
  styles: [

  ]
})
export class AppComponent {
  title = 'FRONT';
}
